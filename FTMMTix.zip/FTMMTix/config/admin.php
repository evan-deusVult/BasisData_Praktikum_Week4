<?php

return [
    'email' => 'admin@example.com',
    'password' => 'admin123', // bisa langsung plain text
];
