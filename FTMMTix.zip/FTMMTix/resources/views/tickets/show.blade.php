@extends('layouts.app')
@section('content')
<h3>E‑Ticket — Order {{ $order->code }}</h3>
<div class="row g-3">
@foreach($tickets as $t)
  <div class="col-md-4">
    <div class="card h-100"><div class="card-body text-center">
      <h5>{{ $t->event->title ?? 'Event' }}</h5>
      <p class="small mb-1">Kode Tiket</p>
      <h6 class="mb-3">{{ $t->code }}</h6>
      @if(class_exists("SimpleSoftwareIO\QrCode\Generator"))
        {!! QrCode::size(160)->generate($t->code) !!}
      @else
        <div class="border p-4">[QR disabled]</div>
      @endif
      <p class="mt-3 small">Tunjukkan QR/kode saat masuk.</p>
    </div></div>
  </div>
@endforeach
</div>
@endsection
