@extends('layouts.app')
@section('content')
<h3>Pembayaran — Order {{ $order->code }}</h3>
<div class="row g-3">
  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <div class="mb-2"><strong>Total Bayar:</strong> Rp {{ number_format($order->total_amount,0,',','.') }}</div>
      <form method="post" action="{{ route('pay.choose',$order) }}">@csrf
        <div class="mb-2"><label class="form-label">Pilih Bank</label>
          <select name="bank_id" class="form-select">
            @foreach($banks as $b)
              <option value="{{ $b->id }}">{{ $b->name }} — {{ $b->account_number }} a.n. {{ $b->account_name }}</option>
            @endforeach
          </select>
        </div>
        <button class="btn btn-primary">Pilih</button>
      </form>
      @if(session('ok'))<div class="alert alert-info mt-2">{{ session('ok') }}</div>@endif
    </div></div>
  </div>

  <div class="col-md-6">
    <div class="card"><div class="card-body">
      <h6>Konfirmasi Transfer</h6>
      <form method="post" action="{{ route('pay.confirm',$order) }}">@csrf
        <div class="mb-2"><label>No. Referensi/BERITA</label><input name="transfer_ref" class="form-control" required></div>
        <button class="btn btn-success">Konfirmasi Pembayaran</button>
      </form>
    </div></div>
  </div>
</div>
@endsection

