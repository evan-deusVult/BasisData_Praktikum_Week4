@extends('layouts.app')

@section('content')
<div class="row g-4">
    <!-- Poster Event -->
    <div class="col-md-4">
        @if($event->poster_url)
            <img src="{{ $event->poster_url }}" alt="{{ $event->title }}" class="img-fluid rounded shadow-sm" />
        @else
            <div class="ratio ratio-4x3 bg-light d-flex align-items-center justify-content-center text-muted">
                No Image
            </div>
        @endif
    </div>

    <!-- Detail Event -->
    <div class="col-md-8">
        <h3 class="fw-bold">{{ $event->title }}</h3>
        <p class="mb-1"><strong>Tanggal</strong>: {{ $event->start_at->format('d M Y H:i') }}</p>
        @if($event->end_at)
        <p class="mb-1"><strong>Selesai</strong>: {{ $event->end_at->format('d M Y H:i') }}</p>
        @endif
        <p class="mb-3"><strong>Tempat</strong>: {{ $event->venue }}</p>

        <!-- Form Pemesanan Tiket -->
        <form method="post" action="{{ route('cart.add',$event) }}">
            @csrf
            <div class="row g-2 align-items-end">
                <div class="col-md-4">
                    <label class="form-label">Tipe Tiket</label>
                    <select name="ticket_type_id" class="form-select">
                        @foreach($event->ticketTypes as $t)
                        <option value="{{ $t->id }}">{{ $t->name }} — Rp {{ number_format($t->price,0,',','.') }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Jumlah</label>
                    <input type="number" min="1" value="1" name="qty" class="form-control" />
                </div>
                <div class="col-md-3">
                    <button class="btn btn-primary w-100">Pesan</button>
                </div>
            </div>
        </form>

        <!-- Deskripsi -->
        <p class="mt-3">{{ $event->description }}</p>
    </div>
</div>
@endsection
