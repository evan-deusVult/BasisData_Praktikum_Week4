<?php
namespace App\Http\Controllers;
use App\Models\{Order};

class TicketController extends Controller
{
    public function show(Order $order){
        abort_if($order->student_id !== auth()->id(), 403);
        $tickets = $order->load('items','payment')->tickets ?? $order->tickets; // if relation added
        return view('tickets.show',[ 'order'=>$order, 'tickets'=>$order->tickets ]);
    }
}
