<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Models\{Event, TicketType, Order, OrderItem, Payment};

class OrderController extends Controller
{
    public function addToCart(Request $request, Event $event)
    {
        $data = $request->validate([
            'ticket_type_id' => 'required|exists:ticket_types,id',
            'qty'            => 'required|integer|min:1'
        ]);

        $tt = TicketType::findOrFail($data['ticket_type_id']);
        $subtotal = $tt->price * $data['qty'];

        session(['cart' => [
            'event_id'       => $event->id,
            'ticket_type_id' => $tt->id,
            'qty'            => $data['qty'],
            'unit_price'     => $tt->price,
            'subtotal'       => $subtotal
        ]]);

        return redirect()->route('checkout');
    }

    public function checkout()
    {
        $cart = session('cart');
        abort_if(!$cart, 404);

        $event = Event::findOrFail($cart['event_id']);
        return view('checkout.index', compact('cart', 'event'));
    }

    public function placeOrder(Request $request)
    {
        if (!auth()->check()) {
            return redirect()->route('login')->withErrors('Harap login dulu sebelum memesan tiket.');
        }

        $cart = session('cart');
        abort_if(!$cart, 404);

        return DB::transaction(function () use ($cart) {
            $order = Order::create([
                'student_id'   => auth()->id(),
                'code'         => 'FTMM-' . now()->format('Ymd') . '-' . Str::upper(Str::random(6)),
                'status'       => 'UNPAID',
                'total_amount' => $cart['subtotal'],
            ]);

            OrderItem::create([
                'order_id'       => $order->id,
                'event_id'       => $cart['event_id'],
                'ticket_type_id' => $cart['ticket_type_id'],
                'qty'            => $cart['qty'],
                'unit_price'     => $cart['unit_price'],
                'subtotal'       => $cart['subtotal'],
            ]);

            Payment::create([
                'order_id' => $order->id,
                'amount'   => $order->total_amount,
                'status'   => 'AWAITING_PAYMENT',
            ]);

            session()->forget('cart');

            return redirect()->route('pay.banks', $order)
                ->with('success', 'Pesanan berhasil dibuat. Silakan pilih metode pembayaran.');
        });
    }
}
