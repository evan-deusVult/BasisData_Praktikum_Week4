<?php
namespace App\Http\Controllers;
use App\Models\Event;

class HomeController extends Controller
{
    public function index(){
        $events = Event::where('is_published',true)
            ->where('start_at','>=',now()->subDay())
            ->orderBy('start_at')
            ->get();
        return view('home', compact('events'));
    }
}


