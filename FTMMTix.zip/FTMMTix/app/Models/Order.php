<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['student_id','code','status','total_amount'];
    const STATUS = ['UNPAID','PAID','CANCELLED','EXPIRED'];

    public function student(){ return $this->belongsTo(Student::class); }
    public function items(){ return $this->hasMany(OrderItem::class); }
    public function payment(){ return $this->hasOne(Payment::class); }
    public function tickets(){ return $this->hasMany(\App\Models\Ticket::class); }

}

