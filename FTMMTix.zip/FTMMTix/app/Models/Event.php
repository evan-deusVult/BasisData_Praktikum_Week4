<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Event extends Model
{
    use HasFactory;
    protected $fillable = [
        'title', 'slug', 'poster_path', 'venue', 'start_at', 'end_at', 'description', 'is_published',
        'category', 'status', 'participants', 'price', 'organizer'
    ];

    public function ticketTypes()
    {
        return $this->hasMany(\App\Models\TicketType::class);
    }
    public function items()
    {
        return $this->hasMany(\App\Models\OrderItem::class);
    }
    public function tickets()
    {
        return $this->hasMany(\App\Models\Ticket::class);
    }

}

