
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center"><div class="col-md-5">
<h3 class="mb-3">Register</h3>
<form method="post" action="<?php echo e(route('register.do')); ?>"><?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="register_type">Register Sebagai</label>
    <select class="form-select" id="register_type" name="register_type" required onchange="updateRegisterFields()">
      <option value="student">Mahasiswa</option>
      <option value="lecturer">Dosen</option>
      <option value="user">Umum</option>
    </select>
  </div>
  <div class="mb-3" id="nim_field">
    <label for="nim">NIM</label>
    <input name="nim" id="nim" class="form-control">
  </div>
  <div class="mb-3 d-none" id="nip_field">
    <label for="nip">NIP</label>
    <input name="nip" id="nip" class="form-control">
  </div>
  <div class="mb-3 d-none" id="email_field">
    <label for="email">Email</label>
    <input type="email" name="email" id="email" class="form-control">
  </div>
  <div class="mb-3">
    <label for="name">Nama</label>
    <input name="name" id="name" class="form-control" required>
  </div>
  <div class="mb-3">
    <label for="password">Password</label>
    <input type="password" name="password" id="password" class="form-control" required>
  </div>
  <button class="btn btn-primary w-100">Register</button>
</form>
<?php if($errors->any()): ?><div class="alert alert-danger mt-3"><?php echo e($errors->first()); ?></div><?php endif; ?>
</div></div>
<script>
function updateRegisterFields() {
  var type = document.getElementById('register_type').value;
  document.getElementById('nim_field').classList.toggle('d-none', type !== 'student');
  document.getElementById('nip_field').classList.toggle('d-none', type !== 'lecturer');
  document.getElementById('email_field').classList.toggle('d-none', type !== 'user');
  document.getElementById('nim').required = (type === 'student');
  document.getElementById('nip').required = (type === 'lecturer');
  document.getElementById('email').required = (type === 'user');
}
  document.addEventListener('DOMContentLoaded', updateRegisterFields);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/auth/register.blade.php ENDPATH**/ ?>