

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Mahasiswa</h1>
    <form action="<?php echo e(route('account.update')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label>NIM</label>
            <input type="text" name="nim" class="form-control" value="<?php echo e($student->nim); ?>">
        </div>
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($student->name); ?>">
        </div>
        <!-- Email dihapus untuk mahasiswa -->
        <div class="mb-3">
            <label>Password (isi jika mau ubah)</label>
            <input type="password" name="password" class="form-control">
        </div>
        <button class="btn btn-primary">Update</button>
    </form>
    <form method="POST" action="<?php echo e(route('account.delete')); ?>" class="d-inline mt-2" onsubmit="return confirm('Yakin ingin menghapus akun? Tindakan ini tidak bisa dibatalkan.');">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger">Hapus Akun</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/students/edit.blade.php ENDPATH**/ ?>