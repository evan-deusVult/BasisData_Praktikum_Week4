

<?php $__env->startSection('title', 'Login Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="max-width:400px;">
    <h2 class="mb-4">Login Admin</h2>
    <form method="POST" action="<?php echo e(route('admin.login.do')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required autofocus>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>