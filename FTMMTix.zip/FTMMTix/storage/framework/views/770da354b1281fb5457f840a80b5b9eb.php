

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detail Event</h1>
    <div class="mb-3">
        <strong>Nama Event:</strong> <?php echo e($event->name); ?>

    </div>
    <div class="mb-3">
        <strong>Tanggal:</strong> <?php echo e($event->date); ?>

    </div>
    <div class="mb-3">
        <strong>Lokasi:</strong> <?php echo e($event->location); ?>

    </div>
    <div class="mb-3">
        <strong>Deskripsi:</strong> <?php echo e($event->description); ?>

    </div>
    <a href="<?php echo e(route('events.edit', $event->id)); ?>" class="btn btn-warning">Edit</a>
    <a href="<?php echo e(route('events.index')); ?>" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/admin/events/show.blade.php ENDPATH**/ ?>