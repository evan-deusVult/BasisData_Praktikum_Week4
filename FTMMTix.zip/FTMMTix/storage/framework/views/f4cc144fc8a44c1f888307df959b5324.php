


<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="p-5 mb-4 bg-light rounded-3 shadow-sm text-center">
    <h1 class="display-4 fw-bold text-primary"><?php echo e($event['title']); ?></h1>
    <p class="lead text-secondary"><?php echo e($event['description']); ?></p>
  </div>

  <div class="row align-items-center">
    <div class="col-md-6">
      <img src="<?php echo e(asset($event['image'])); ?>" class="img-fluid rounded shadow-sm" alt="<?php echo e($event['title']); ?>">
    </div>
    <div class="col-md-6">
      <div class="bg-white p-4 rounded shadow-sm">
        <h3 class="text-warning fw-bold">Detail Event</h3>
        <ul class="list-unstyled fs-5">
          <li><strong class="text-primary">Tanggal:</strong> <?php echo e($event['date']); ?></li>
          <li><strong class="text-primary">Tempat:</strong> <?php echo e($event['location']); ?></li>
          <li><strong class="text-primary">Harga:</strong> Rp<?php echo e(number_format($event['price'], 0, ',', '.')); ?></li>
        </ul>
        <a href="<?php echo e(route('order.create', ['id' => $event['id']])); ?>" class="btn btn-success btn-lg mt-3">Pesan Tiket</a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/event-detail.css')); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/event-detail.blade.php ENDPATH**/ ?>