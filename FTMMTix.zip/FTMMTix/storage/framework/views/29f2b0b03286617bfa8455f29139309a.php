

<?php $__env->startSection('content'); ?>
<div class="container py-5">


<div class="text-center mb-5">
  <span class="badge bg-light text-dark mb-2">FTMMTIX - Event & Ticketing Platform</span>

  <!-- Logo FTMMTIX -->
  <div class="my-3">
    <img src="<?php echo e(asset('images/logo-ftmm-tix2.jpg')); ?>" 
         alt="FTMMTIX Logo" 
         width="300" 
         class="img-fluid">
  </div>

  <h1 class="fw-bold">Find & Join Exciting Events of FTMM</h1>
  <p class="text-muted">
    From academic seminars to basketball matches — book your tickets easily and be part of the experience.
  </p>

  <div class="d-flex justify-content-center gap-5 mt-4">
    <div>
      <h4 class="fw-bold">6</h4>
      <p class="text-muted mb-0">Upcoming Events</p>
    </div>
    <div>
      <h4 class="fw-bold">3</h4>
      <p class="text-muted mb-0">Free Events</p>
    </div>
    <div>
      <h4 class="fw-bold">1000+</h4>
      <p class="text-muted mb-0">Tickets Sold</p>
    </div>
  </div>
</div>


  
  <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
    <div class="flex-grow-1 me-2">
      <input type="text" class="form-control" placeholder="Search events...">
    </div>
    <div class="dropdown me-2">
      <button class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">All Prices</button>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#">All Prices</a></li>
        <li><a class="dropdown-item" href="#">Free</a></li>
        <li><a class="dropdown-item" href="#">Paid</a></li>
      </ul>
    </div>
    <button class="btn btn-outline-secondary"><i class="bi bi-funnel"></i></button>
  </div>

  
  <div class="mb-4">
    <button class="btn btn-dark btn-sm me-2">All</button>
    <button class="btn btn-outline-dark btn-sm me-2">Workshop</button>
    <button class="btn btn-outline-dark btn-sm me-2">Seminar</button>
    <button class="btn btn-outline-dark btn-sm me-2">Sports</button>
    <button class="btn btn-outline-dark btn-sm">Networking</button>
  </div>

  
  <?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->role === 'admin'): ?>
      <div class="mb-4 text-end">
        <a href="<?php echo e(route('admin.events.create')); ?>" class="btn btn-primary">
          <i class="bi bi-plus"></i> Tambah Event
        </a>
      </div>
    <?php endif; ?>
  <?php endif; ?>

  
  <div class="row g-4">
    <?php
      $dummyEvents = [
        [
          'id' => 1,
          'title' => 'Basket FTMM Championship',
          'poster' => 'basket-ftmm.jpg',
          'category' => 'Sports',
          'status' => 'Almost Full',
          'date' => 'Mei 18, 2025',
          'time' => '16:00 - 17.00 WIB',
          'location' => 'GOR FTMM',
          'participants' => '80/100',
          'price' => 'Rp 25.000',
          'organizer' => 'FTMM Sports Club',
        ],
        [
          'id' => 2,
          'title' => 'Internship Duta FTMM',
          'poster' => 'internship-duta-ftmm.jpg',
          'category' => 'Networking',
          'status' => 'Open',
          'date' => 'September 12-19, 2025',
          'time' => '09:00 - 12:00 WIB',
          'location' => 'Auditorium FTMM',
          'participants' => '200/300',
          'price' => 'Free',
          'organizer' => 'FTMM Duta Team',
        ],
        [
          'id' => 3,
          'title' => 'Festival Petasan Kreatif',
          'poster' => 'petasan.jpg',
          'category' => 'Festival',
          'status' => 'Limited',
          'date' => 'August 17, 2025',
          'time' => '15:00 WIB',
          'location' => 'Lapangan FTMM',
          'participants' => '200/200',
          'price' => 'Rp 50.000',
          'organizer' => 'FTMM Sports & Arts',
        ],
      ];
    ?>

    
    <?php $__currentLoopData = $dummyEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6 col-lg-4">
        <div class="event-card h-100">
          <img src="<?php echo e(asset('images/'.$event['poster'])); ?>" class="w-100" alt="<?php echo e($event['title']); ?>">
          <div class="p-3">
            <div class="d-flex justify-content-between mb-2">
              <span class="badge bg-primary"><?php echo e($event['category']); ?></span>
              <span class="badge bg-danger"><?php echo e($event['status']); ?></span>
            </div>
            <h5 class="fw-bold"><?php echo e($event['title']); ?></h5>
            <ul class="list-unstyled small text-muted mb-3">
              <li><i class="bi bi-calendar-event"></i> <?php echo e($event['date']); ?></li>
              <li><i class="bi bi-clock"></i> <?php echo e($event['time']); ?></li>
              <li><i class="bi bi-geo-alt"></i> <?php echo e($event['location']); ?></li>
              <li><i class="bi bi-people"></i> <?php echo e($event['participants']); ?> participants</li>
            </ul>
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <strong><?php echo e($event['price']); ?></strong><br>
                <small class="text-muted">by <?php echo e($event['organizer']); ?></small>
              </div>
              <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-dark btn-sm">Get Ticket</a>
              <?php endif; ?>
              <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/event/'.$event['id'])); ?>" class="btn btn-dark btn-sm">Get Ticket</a>
                <?php if(auth()->user()->role === 'admin'): ?>
                  <div class="ms-2 d-flex flex-column gap-1">
                    <a href="<?php echo e(route('admin.events.edit', $event['id'])); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('admin.events.destroy', $event['id'])); ?>" method="POST">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventDB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(is_object($eventDB)): ?>
      <div class="col-md-6 col-lg-4">
        <div class="event-card h-100">
          <img src="<?php echo e($eventDB->poster_path ? asset('storage/'.$eventDB->poster_path) : asset('images/default-event.jpg')); ?>" class="w-100" alt="<?php echo e($eventDB->title); ?>" style="background:#f0f0f0;object-fit:cover;min-height:220px;max-height:220px;">
          <div class="p-3">
            <div class="d-flex justify-content-between mb-2">
              <span class="badge bg-primary"><?php echo e($eventDB->category ?? 'Event'); ?></span>
              <span class="badge bg-danger"><?php echo e($eventDB->status ?? ($eventDB->is_published ? 'Open' : 'Draft')); ?></span>
            </div>
            <h5 class="fw-bold"><?php echo e($eventDB->title); ?></h5>
            <ul class="list-unstyled small text-muted mb-3">
              <li><i class="bi bi-calendar-event"></i> <?php echo e(\Carbon\Carbon::parse($eventDB->start_at)->translatedFormat('F d, Y')); ?></li>
              <li><i class="bi bi-clock"></i> <?php echo e($eventDB->start_at ? \Carbon\Carbon::parse($eventDB->start_at)->format('H:i') : '-'); ?><?php echo e($eventDB->end_at ? ' - '.\Carbon\Carbon::parse($eventDB->end_at)->format('H:i') : ''); ?> WIB</li>
              <li><i class="bi bi-geo-alt"></i> <?php echo e($eventDB->venue); ?></li>
              <li><i class="bi bi-people"></i> <?php echo e($eventDB->participants ?? '-'); ?> participants</li>
              <li><i class="bi bi-cash"></i> <?php echo e($eventDB->price == 0 ? 'Free' : 'Rp '.number_format($eventDB->price,0,',','.')); ?></li>
            </ul>
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <strong><?php echo e($eventDB->price == 0 ? 'Free' : 'Rp '.number_format($eventDB->price,0,',','.')); ?></strong><br>
                <small class="text-muted">by <?php echo e($eventDB->organizer ?? 'Admin'); ?></small>
              </div>
              <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-dark btn-sm">Get Ticket</a>
              <?php endif; ?>
              <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/event/'.$eventDB->id)); ?>" class="btn btn-dark btn-sm">Get Ticket</a>
                <?php if(auth()->user()->role === 'admin'): ?>
                  <div class="ms-2 d-flex flex-column gap-1">
                    <a href="<?php echo e(route('admin.events.edit', $eventDB->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('admin.events.destroy', $eventDB->id)); ?>" method="POST">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                  </div>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/home.blade.php ENDPATH**/ ?>