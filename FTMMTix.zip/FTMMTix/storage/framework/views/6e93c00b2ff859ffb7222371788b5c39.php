

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="p-5 mb-4 bg-light rounded-3 shadow-sm text-center">
    <h1 class="display-4 fw-bold text-primary">Pesan Tiket</h1>
    <p class="lead text-secondary">Isi formulir di bawah untuk memesan tiket event <strong><?php echo e($event['title']); ?></strong>.</p>
  </div>

  <div class="row justify-content-center">
    <div class="col-md-8">
      <div class="bg-white p-4 rounded shadow-sm">
        <form action="<?php echo e(route('order.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="event_id" value="<?php echo e($event['id']); ?>">

          <div class="mb-3">
            <label for="name" class="form-label text-primary">Nama Lengkap</label>
            <input type="text" class="form-control" id="name" name="name" placeholder="Masukkan nama lengkap Anda" required>
          </div>

          <div class="mb-3">
            <label for="email" class="form-label text-primary">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email Anda" required>
          </div>

          <div class="mb-3">
            <label for="quantity" class="form-label text-primary">Jumlah Tiket</label>
            <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Masukkan jumlah tiket" min="1" required>
          </div>

          <div class="d-grid">
            <button type="submit" class="btn btn-success btn-lg">Pesan Sekarang</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/order-ticket.blade.php ENDPATH**/ ?>