

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h1>Dashboard Admin</h1>
    <p>Selamat datang di dashboard admin FTMMTix!</p>

    <a href="<?php echo e(route('admin.events.create')); ?>" class="btn btn-primary mb-3">+ Tambah Event</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>Judul</th>
            <th>Venue</th>
            <th>Waktu Mulai</th>
            <th>Waktu Selesai</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
        <?php $__currentLoopData = \App\Models\Event::orderByDesc('start_at')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($event->title); ?></td>
            <td><?php echo e($event->venue); ?></td>
            <td><?php echo e($event->start_at); ?></td>
            <td><?php echo e($event->end_at); ?></td>
            <td><?php echo e($event->is_published ? 'Published' : 'Draft'); ?></td>
            <td>
                <a href="<?php echo e(route('admin.events.edit', $event->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>