

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Event</h1>
    <form action="<?php echo e(route('admin.events.update', $event->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="name" class="form-label">Nama Event</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($event->title); ?>" required>
        </div>
        <div class="mb-3">
            <label for="category" class="form-label">Kategori</label>
            <input type="text" class="form-control" id="category" name="category" value="<?php echo e($event->category); ?>" required>
        </div>
        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <input type="text" class="form-control" id="status" name="status" value="<?php echo e($event->status); ?>" required>
        </div>
        <div class="mb-3 row">
            <div class="col">
                <label for="date" class="form-label">Tanggal</label>
                <input type="date" class="form-control" id="date" name="date" value="<?php echo e(\Carbon\Carbon::parse($event->start_at)->format('Y-m-d')); ?>" required>
            </div>
            <div class="col">
                <label for="start_time" class="form-label">Jam Mulai</label>
                <input type="time" class="form-control" id="start_time" name="start_time" value="<?php echo e(\Carbon\Carbon::parse($event->start_at)->format('H:i')); ?>" required>
            </div>
            <div class="col">
                <label for="end_time" class="form-label">Jam Selesai</label>
                <input type="time" class="form-control" id="end_time" name="end_time" value="<?php echo e(\Carbon\Carbon::parse($event->end_at)->format('H:i')); ?>" required>
            </div>
        </div>
        <div class="mb-3">
            <label for="location" class="form-label">Lokasi</label>
            <input type="text" class="form-control" id="location" name="location" value="<?php echo e($event->venue); ?>" required>
        </div>
        <div class="mb-3">
            <label for="participants" class="form-label">Peserta (cth: 80/100)</label>
            <input type="text" class="form-control" id="participants" name="participants" value="<?php echo e($event->participants); ?>">
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Harga (Rp)</label>
            <input type="number" class="form-control" id="price" name="price" min="0" value="<?php echo e($event->price); ?>">
        </div>
        <div class="mb-3">
            <label for="organizer" class="form-label">Penyelenggara</label>
            <input type="text" class="form-control" id="organizer" name="organizer" value="<?php echo e($event->organizer); ?>">
        </div>
        <div class="mb-3">
            <label for="poster" class="form-label">Poster Event</label>
            <input type="file" class="form-control" id="poster" name="poster" accept="image/*">
            <?php if($event->poster_path): ?>
                <img src="<?php echo e(asset('storage/'.$event->poster_path)); ?>" alt="Poster" style="max-width:120px;max-height:120px;" class="mt-2">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Deskripsi</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo e($event->description); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    <a href="/" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/admin/events/edit.blade.php ENDPATH**/ ?>