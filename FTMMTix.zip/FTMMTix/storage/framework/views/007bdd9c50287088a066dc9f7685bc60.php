

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Daftar Event</h1>
    <a href="<?php echo e(route('admin.events.create')); ?>" class="btn btn-primary mb-3">Tambah Event</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Tanggal Mulai</th>
                <th>Lokasi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($event->id); ?></td>
                <td><?php echo e($event->title); ?></td>
                <td><?php echo e($event->start_at); ?></td>
                <td><?php echo e($event->venue); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.events.show', $event->id)); ?>" class="btn btn-info btn-sm">Detail</a>
                    <a href="<?php echo e(route('admin.events.edit', $event->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus event?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\FTMMTix\resources\views/admin/events/index.blade.php ENDPATH**/ ?>