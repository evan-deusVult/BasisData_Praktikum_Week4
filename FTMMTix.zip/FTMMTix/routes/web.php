<?php
use App\Http\Controllers\Admin\AdminController;


// Admin Auth
use App\Http\Controllers\Admin\AdminAuthController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\StudentController;

// Register
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.do');

Route::get('/admin/login', [AdminAuthController::class, 'showLogin'])->name('admin.login');
Route::post('/admin/login', [AdminAuthController::class, 'login'])->name('admin.login.do');
Route::post('/admin/logout', [AdminAuthController::class, 'logout'])->name('admin.logout');
Route::get('/', [HomeController::class, 'index'])->name('home');

// Auth (NIM+password)
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.do');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Events
Route::get('/events', [EventController::class, 'index'])->name('events.index');
Route::get('/events/{event:slug}', [EventController::class, 'show'])->name('events.show');
Route::get('/event/{id}', function ($id) {
    $events = [
        1 => [
            'id' => 1,
            'title' => 'Internship Duta FTMM',
            'description' => 'Program magang untuk menjadi duta FTMM.',
            'image' => 'images/internship-duta-ftmm.jpg',
            'date' => '2025-10-15',
            'location' => 'Aula FTMM',
            'price' => 25000,
        ],
        2 => [
            'id' => 2,
            'title' => 'Synreach FTMM',
            'description' => 'Seminar teknologi dan inovasi di FTMM.',
            'image' => 'images/synreach-ftmm.jpg',
            'date' => '2025-11-05',
            'location' => 'Aula Kampus',
            'price' => 50000,
        ],
        3 => [
            'id' => 3,
            'title' => 'Nama Event 3',
            'description' => 'Deskripsi untuk event 3.',
            'image' => 'images/event-poster-sample.jpg',
            'date' => '2025-12-10',
            'location' => 'Aula FTMM',
            'price' => 30000,
        ],
        4 => [
            'id' => 4,
            'title' => 'Nama Event 4',
            'description' => 'Deskripsi untuk event 4.',
            'image' => 'images/event-poster-sample.jpg',
            'date' => '2026-01-20',
            'location' => 'Aula FTMM',
            'price' => 40000,
        ],
    ];
    $event = $events[$id] ?? abort(404);

    return view('event-detail', compact('event'));

});

Route::get('/event/{id}/order', function ($id) {
    // Dummy data untuk contoh
    $events = [
        1 => [
            'id' => 1,
            'title' => 'Internship Duta FTMM',
            'description' => 'Program magang untuk menjadi duta FTMM.',
            'image' => 'images/internship-duta-ftmm.jpg',
            'date' => '2025-10-15',
            'location' => 'Aula FTMM',
            'price' => 25000,
        ],
        2 => [
            'id' => 2,
            'title' => 'Synreach FTMM',
            'description' => 'Seminar teknologi dan inovasi di FTMM.',
            'image' => 'images/synreach-ftmm.jpg',
            'date' => '2025-11-05',
            'location' => 'Aula Kampus',
            'price' => 50000,
        ],
        // Tambahkan event lainnya...
    ];

    $event = $events[$id] ?? abort(404);

    return view('order-ticket', compact('event'));
})->name('order.create');

Route::post('/order', function (Illuminate\Http\Request $request) {
    // Proses penyimpanan data pesanan tiket
    $data = $request->all();
    // Simpan data ke database atau lakukan logika lainnya
    return redirect()->route('home')->with('success', 'Tiket berhasil dipesan!');
})->name('order.store');

// Protected flow
Route::middleware('auth')->group(function () {
    // Cart & checkout
    Route::post('/events/{event:slug}/add', [OrderController::class, 'addToCart'])->name('cart.add');
    Route::get('/checkout', [OrderController::class, 'checkout'])->name('checkout');
    Route::post('/checkout', [OrderController::class, 'placeOrder'])->name('checkout.place');

    // Payment (bank transfer)
    Route::get('/pay/{order}', [PaymentController::class, 'showBanks'])->name('pay.banks');
    Route::post('/pay/{order}/choose', [PaymentController::class, 'chooseBank'])->name('pay.choose');
    Route::post('/pay/{order}/confirm', [PaymentController::class, 'confirmTransfer'])->name('pay.confirm');

    // E-ticket
    Route::get('/tickets/{order}', [TicketController::class, 'show'])->name('tickets.show');
});

// --- ADMIN ONLY ---
// --- CRUD Student, bisa diakses semua user login ---


// Route untuk user biasa dan dosen: edit, update, hapus akun sendiri
Route::middleware(['auth','guest:lecturer'])->group(function () {
    Route::get('/account/edit', function() {
        if(auth('lecturer')->check()) {
            return app(\App\Http\Controllers\LecturerController::class)->editSelf();
        } else {
            return app(\App\Http\Controllers\StudentController::class)->editSelf();
        }
    })->name('account.edit');
    Route::put('/account/update', function(Request $request) {
        if(auth('lecturer')->check()) {
            return app(\App\Http\Controllers\LecturerController::class)->updateSelf($request);
        } else {
            return app(\App\Http\Controllers\StudentController::class)->updateSelf($request);
        }
    })->name('account.update');
    Route::delete('/account/delete', function(Request $request) {
        if(auth('lecturer')->check()) {
            return app(\App\Http\Controllers\LecturerController::class)->destroySelf($request);
        } else {
            return app(\App\Http\Controllers\StudentController::class)->destroySelf($request);
        }
    })->name('account.delete');
});

// routes/web.php


Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
    // Admin hanya bisa hapus akun lain
    Route::delete('/admin/students/{id}', [\App\Http\Controllers\StudentController::class, 'destroy'])->name('admin.students.destroy');
    Route::resource('/admin/events', \App\Http\Controllers\Admin\AdminEventController::class)->names('admin.events');
});

Route::middleware(['auth', 'role:user'])->group(function () {
    Route::get('/user/dashboard', [UserController::class, 'index'])->name('user.dashboard');
});

Route::middleware('auth')->group(function () {
    Route::resource('students', StudentController::class);
});
